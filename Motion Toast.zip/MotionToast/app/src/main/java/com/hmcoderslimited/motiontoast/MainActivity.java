package com.hmcoderslimited.motiontoast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.lazyprogrammer.motiontoast.MotionStyle;
import com.lazyprogrammer.motiontoast.MotionToast;


public class MainActivity extends AppCompatActivity {

    Button clickToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        clickToast = findViewById(R.id.clickToast);



        clickToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MotionToast motionToast =
                        new MotionToast(MainActivity.this,
                                0,
                                MotionStyle.DARK,
                                MotionStyle.SUCCESS,
                                MotionStyle.BOTTOM,
                                "SUCCESS",
                                "You got a reward :)",
                                MotionStyle.LENGTH_LONG)
                                .show();

            }
        });





    }
}